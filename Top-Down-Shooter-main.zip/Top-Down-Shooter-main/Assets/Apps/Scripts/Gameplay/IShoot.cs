﻿public interface IShoot
{
    void Shoot();
}